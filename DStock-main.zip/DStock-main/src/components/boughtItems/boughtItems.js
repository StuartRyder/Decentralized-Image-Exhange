import React from 'react'

function BoughtItems() {
    return (
        <div>
            This contains the items purchased by me.
        </div>
    )
}

export default BoughtItems
